import serial
import serial.tools.list_ports as list_ports
import time
import matplotlib.pyplot as plt

baud = 115200

def findComport(baud):
    serPort = serial.Serial(timeout=0.1)
    serPort.baudrate = baud
    ports = list(list_ports.comports())
    print('Scanning ports')
    
    for p in ports:
        print('Port: {}'.format(p))
        serPort.port = str(p.device)
        return serPort
    
    return None

def main():
    global chartNums
    chartNums = []

    numCheck = ['0','1','2','3','4','5','6','7','8','9']

    print('Looking for microbit')
    serMicro = findComport(baud)
    
    if not serMicro:
        print('Microbit not found')
        print('Exiting in 10 seconds...')
        time.sleep(10)
        return
    
    print('Running Microbit terminal...\n\n')
    serMicro.open()
    
    while True:
        message = serMicro.readline().decode('utf-8')
        message = message.strip()
        if message:
            print(message,'\n')

        if message in numCheck:
            chartNums.append(message)
            #print(chartNums)

        if message == 'break':
            break

def plotDictionary():
    dic = {'0':0, '1':0, '2':0, '3':0, '4':0, '5':0, '6':0, '7':0, '8':0, '9':0}
    
    dic.update({i:chartNums.count(i) for i in chartNums})

    keys = list(dic.keys())
    values = list(dic.values())
    
    plt.bar(range(len(dic)), values, tick_label = keys)
    plt.yticks(values)

    plt.title("0 = don't understand entirely, 9 = understand completely")
    plt.xlabel("Range from 0 - 9")
    plt.ylabel("Amount of people per number")
    plt.show()


main()
plotDictionary()


